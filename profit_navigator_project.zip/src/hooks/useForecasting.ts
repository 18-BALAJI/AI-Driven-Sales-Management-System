import { useState, useEffect, useCallback } from "react";
import { fetchForecast, fetchTransactions } from "@/lib/api";
import { performLinearRegression, predictFuture } from "@/lib/ml";

export type ForecastResult = {
    period: string;
    predicted_revenue: number;
    predicted_expenses: number;
    predicted_profit?: number;
    predicted_revenue_upper?: number;
    predicted_revenue_lower?: number;
    profit_margin?: number;
    confidence: number;
};

export type ChartPoint = {
    month: string;
    actual: number | null;
    forecast: number | null;
    forecastUpper?: number | null;
    forecastLower?: number | null;
    expenses?: number | null;
};

export function useForecasting() {
    const [loading, setLoading] = useState(true);
    const [chartData, setChartData] = useState<ChartPoint[]>([]);
    const [forecasts, setForecasts] = useState<ForecastResult[]>([]);
    const [modelUsed, setModelUsed] = useState<string>("prophet");
    const [r2Score, setR2Score] = useState<number>(0.92);
    const [error, setError] = useState<string | null>(null);

    const calculateForecast = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const res = await fetchForecast().catch(() => null);

            if (res && res.forecasts && res.forecasts.length > 0) {
                setForecasts(res.forecasts);
                setModelUsed(res.model_used || "prophet");
                setR2Score(res.r2_score || 0.92);

                const historicalMonths = res.historical?.months || [];
                const historicalRevenues = res.historical?.revenues || [];
                const historicalExpenses = res.historical?.expenses || [];

                const historicalPoints: ChartPoint[] = historicalMonths.map((m, i) => {
                    const date = new Date(m + "-01");
                    return {
                        month: date.toLocaleString('default', { month: 'short' }),
                        actual: historicalRevenues[i] || 0,
                        forecast: null,
                        expenses: historicalExpenses[i] || 0,
                    };
                });

                const forecastPoints: ChartPoint[] = res.forecasts.map(f => ({
                    month: f.period.split(' ')[0],
                    actual: null,
                    forecast: f.predicted_revenue,
                    forecastUpper: f.predicted_revenue_upper || Math.round(f.predicted_revenue * 1.08),
                    forecastLower: f.predicted_revenue_lower || Math.round(f.predicted_revenue * 0.92),
                    expenses: f.predicted_expenses,
                }));

                setChartData([...historicalPoints, ...forecastPoints]);
                setLoading(false);
                return;
            }

            // Fallback: Fetch transactions and calculate locally if API returns empty
            const transactions = await fetchTransactions();
            if (!transactions || transactions.length === 0) {
                setLoading(false);
                return;
            }

            const monthlyData: Record<string, { income: number; expense: number }> = {};
            transactions.forEach(t => {
                const date = new Date(t.date);
                const monthKey = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
                if (!monthlyData[monthKey]) monthlyData[monthKey] = { income: 0, expense: 0 };
                if (t.type === "income") monthlyData[monthKey].income += Number(t.amount);
                else monthlyData[monthKey].expense += Number(t.amount);
            });

            const monthKeys = Object.keys(monthlyData).sort();
            const revenues = monthKeys.map(k => monthlyData[k].income);
            const expenses = monthKeys.map(k => monthlyData[k].expense);

            const revReg = performLinearRegression(revenues);
            const expReg = performLinearRegression(expenses);
            const n = revenues.length;
            const futureCount = 6;

            const projectedRevenues = predictFuture(revReg.slope, revReg.intercept, n, futureCount);
            const projectedExpenses = predictFuture(expReg.slope, expReg.intercept, n, futureCount);

            const historicalPoints: ChartPoint[] = monthKeys.map((k, i) => {
                const date = new Date(k + "-01");
                return {
                    month: date.toLocaleString('default', { month: 'short' }),
                    actual: revenues[i],
                    forecast: null,
                    expenses: expenses[i],
                };
            });

            const lastHistoricalDate = new Date(monthKeys[n - 1] + "-01");
            const forecastPoints: ChartPoint[] = [];
            const newForecasts: ForecastResult[] = [];

            for (let i = 0; i < futureCount; i++) {
                const futureDate = new Date(lastHistoricalDate.getFullYear(), lastHistoricalDate.getMonth() + i + 1, 1);
                const monthName = futureDate.toLocaleString('default', { month: 'short' });
                const periodName = futureDate.toLocaleString('default', { month: 'short', year: '2-digit' });
                const pRev = projectedRevenues[i];
                const pExp = projectedExpenses[i];
                const pProfit = Math.max(0, pRev - pExp);

                forecastPoints.push({
                    month: monthName,
                    actual: null,
                    forecast: pRev,
                    forecastUpper: Math.round(pRev * 1.08),
                    forecastLower: Math.round(pRev * 0.92),
                    expenses: pExp,
                });

                newForecasts.push({
                    period: periodName,
                    predicted_revenue: pRev,
                    predicted_expenses: pExp,
                    predicted_profit: pProfit,
                    predicted_revenue_upper: Math.round(pRev * 1.08),
                    predicted_revenue_lower: Math.round(pRev * 0.92),
                    profit_margin: pRev > 0 ? round((pProfit / pRev * 100), 1) : 0,
                    confidence: Math.max(0.5, 0.95 - i * 0.05) * revReg.r2
                });
            }

            setChartData([...historicalPoints, ...forecastPoints]);
            setForecasts(newForecasts);
            setModelUsed("linear_regression");
            setR2Score(revReg.r2);

        } catch (e: any) {
            console.error("Forecasting error:", e);
            setError(e.message || "An error occurred during forecasting");
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        calculateForecast();
        const interval = setInterval(calculateForecast, 30000);
        return () => clearInterval(interval);
    }, [calculateForecast]);

    return { loading, chartData, forecasts, modelUsed, r2Score, error, refresh: calculateForecast };
}

function round(val: number, decimals = 1) {
    return Number(Math.round(Number(val + "e" + decimals)) + "e-" + decimals);
}


