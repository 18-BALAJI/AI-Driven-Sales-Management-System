import { useState, useEffect, useCallback } from "react";
import { fetchAnomalies, fetchTransactions } from "@/lib/api";

export type Anomaly = {
  id: string;
  date: string;
  type: "spike" | "drop" | "unusual";
  metric: string;
  description: string;
  severity: "high" | "medium" | "low";
  value: number;
  expected: number;
  riskScore?: number;
  rootCause?: string;
  suggestedAction?: string;
  deviationPct?: number;
};

export function useAnomalies() {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [modelUsed, setModelUsed] = useState<string>("isolation_forest");
  const [loading, setLoading] = useState(true);

  const detectAnomaliesFallback = useCallback((transactions: any[]) => {
    const detected: Anomaly[] = [];
    const categories = Array.from(new Set(transactions.map(t => t.category)));

    categories.forEach(cat => {
      const catTransactions = transactions.filter(t => t.category === cat);
      if (catTransactions.length < 3) return;

      const amounts = catTransactions.map(t => Number(t.amount));
      const avg = amounts.reduce((a, b) => a + b, 0) / amounts.length;
      const stdDev = Math.sqrt(amounts.map(x => Math.pow(x - avg, 2)).reduce((a, b) => a + b, 0) / amounts.length);

      catTransactions.forEach(t => {
        const val = Number(t.amount);
        if (val > avg + 2.5 * stdDev) {
          detected.push({
            id: t.id,
            date: t.date,
            type: "spike",
            metric: `${cat} Expense`,
            description: `Unusually high ${cat} cost detected. This is ${Math.round((val/avg)*100)}% above baseline.`,
            severity: val > avg * 4 ? "high" : "medium",
            value: val,
            expected: Math.round(avg)
          });
        }
      });
    });

    return detected.sort((a, b) => b.date.localeCompare(a.date));
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchAnomalies();
      if (res && res.anomalies) {
        setAnomalies(res.anomalies);
        setModelUsed(res.model_used || "isolation_forest");
        setLoading(false);
        return;
      }
    } catch (e) {
      console.warn("Backend anomaly API unavailable, using client fallback:", e);
    }

    const data = await fetchTransactions().catch(() => []);
    if (data) setAnomalies(detectAnomaliesFallback(data));
    setModelUsed("zscore");
    setLoading(false);
  }, [detectAnomaliesFallback]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  return { anomalies, modelUsed, loading, refresh: fetchData };
}

