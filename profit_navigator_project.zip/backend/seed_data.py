"""
Seed realistic transaction history so the dashboard charts have data:
  - Revenue & Profit Trend (monthly income vs expense)
  - Growth Analysis & Forecasting (daily sales + projection)
  - Sales Forecasting page (monthly Prophet/linear forecast)

Generates ~12 months of daily sales (income) with weekday/weekend and seasonal
patterns plus recurring business expenses (rent, payroll, supplies, utilities).

Run:  python backend/seed_data.py            (clears + reseeds transactions)
      python backend/seed_data.py --keep     (append without clearing)
"""
import os
import sys
import random
from datetime import date, timedelta

sys.path.insert(0, os.path.dirname(__file__))
import db  # noqa: E402

random.seed(42)

DAYS = 365
TODAY = date.today()
START = TODAY - timedelta(days=DAYS)

SALES_DESCRIPTIONS = [
    "Counter sales", "Online order", "Catering order", "Walk-in sales",
    "Card payment batch", "Mobile app order",
]
EXPENSE_PLAN = {
    "Rent": (1, 3500),         # 1st of month
    "Utilities": (5, 600),      # 5th of month
}


def daily_income_total(d: date, idx: int) -> float:
    base = 1500
    trend = 1 + 0.0008 * idx                 # gentle year-long growth
    weekend = 1.35 if d.weekday() >= 5 else 1.0
    december = 1.25 if d.month == 12 else 1.0
    noise = random.uniform(0.85, 1.15)
    return round(base * trend * weekend * december * noise, 2)


def build_rows():
    rows = []  # (date, description, category, amount, type)

    # ── Daily sales (income), split into a few realistic "orders" ────────────
    for idx in range(DAYS + 1):
        d = START + timedelta(days=idx)
        total = daily_income_total(d, idx)
        n_orders = random.randint(3, 6)
        # Split the day's total across n orders.
        cuts = sorted(random.uniform(0, 1) for _ in range(n_orders - 1))
        bounds = [0.0, *cuts, 1.0]
        for j in range(n_orders):
            amt = round(total * (bounds[j + 1] - bounds[j]), 2)
            if amt <= 0:
                continue
            rows.append((d.isoformat(), random.choice(SALES_DESCRIPTIONS),
                         "Sales", amt, "income"))

    # ── Recurring monthly expenses ───────────────────────────────────────────
    cur = date(START.year, START.month, 1)
    while cur <= TODAY:
        for label, (day, amount) in EXPENSE_PLAN.items():
            try:
                ed = cur.replace(day=day)
            except ValueError:
                continue
            if START <= ed <= TODAY:
                jitter = round(amount * random.uniform(0.97, 1.03), 2)
                rows.append((ed.isoformat(), f"{label} — monthly", label, jitter, "expense"))
        # Payroll on the 1st and 15th
        for pay_day in (1, 15):
            try:
                pd = cur.replace(day=pay_day)
            except ValueError:
                continue
            if START <= pd <= TODAY:
                rows.append((pd.isoformat(), "Staff payroll", "Payroll", 4000.00, "expense"))
        # advance one month
        cur = (cur.replace(day=28) + timedelta(days=7)).replace(day=1)

    # ── Weekly supply purchases (every Monday) + occasional equipment ────────
    d = START
    while d <= TODAY:
        if d.weekday() == 0:  # Monday
            rows.append((d.isoformat(), "Inventory restock", "Supplies",
                         round(random.uniform(650, 950), 2), "expense"))
        d += timedelta(days=1)
    # A couple of one-off equipment expenses (creates a realistic anomaly)
    rows.append(((START + timedelta(days=210)).isoformat(),
                 "New espresso machine", "Equipment", 8200.00, "expense"))
    rows.append(((START + timedelta(days=300)).isoformat(),
                 "POS system upgrade", "Equipment", 2400.00, "expense"))

    return rows


PRODUCTS_DATA = [
    ("iPhone 15 Pro Max", "Electronics", 1100.00, 140, 154000.00, "up", "star"),
    ("Samsung Galaxy S24", "Electronics", 950.00, 95, 90250.00, "up", "star"),
    ("Casio G-Shock Watch", "Accessories", 120.00, 310, 37200.00, "up", "cash-cow"),
    ("MacBook Pro M3", "Computers", 1999.00, 45, 89955.00, "up", "star"),
    ("Sony WH-1000XM5 Headphones", "Audio", 349.00, 180, 62820.00, "up", "cash-cow"),
    ("Logitech MX Master 3S", "Accessories", 99.00, 420, 41580.00, "up", "cash-cow"),
    ("Dell UltraSharp 27 Monitor", "Electronics", 450.00, 65, 29250.00, "stable", "question-mark"),
    ("Mechanical Gaming Keyboard", "Accessories", 85.00, 210, 17850.00, "down", "question-mark"),
    ("USB-C Fast Charger 65W", "Accessories", 29.00, 650, 18850.00, "up", "cash-cow"),
    ("Ergonomic Office Chair", "Furniture", 299.00, 28, 8372.00, "down", "underperformer"),
    ("Wireless Earbuds Pro", "Audio", 149.00, 115, 17135.00, "stable", "question-mark"),
    ("Desk Mat XL", "Accessories", 19.00, 340, 6460.00, "down", "underperformer"),
]


def seed_products(clear=True):
    if clear:
        db.execute("DELETE FROM products")
        print("Cleared existing products.")
    
    import uuid
    p_rows = []
    for name, cat, price, units, rev, trend, cluster in PRODUCTS_DATA:
        p_rows.append((str(uuid.uuid4()), name, cat, price, units, rev, trend, cluster))
        
    db.execute_many(
        "INSERT INTO products (id, name, category, price, units_sold, revenue, trend, cluster) "
        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
        p_rows
    )
    print(f"Inserted {len(p_rows)} realistic products.")


def main():
    keep = "--keep" in sys.argv
    rows = build_rows()

    if not keep:
        db.execute("DELETE FROM transactions")
        print("Cleared existing transactions.")

    db.execute_many(
        "INSERT INTO transactions (date, description, category, amount, type) "
        "VALUES (%s, %s, %s, %s, %s)",
        rows,
    )

    seed_products(clear=not keep)

    income = sum(r[3] for r in rows if r[4] == "income")
    expense = sum(r[3] for r in rows if r[4] == "expense")
    print(f"Inserted {len(rows)} transactions "
          f"({sum(1 for r in rows if r[4]=='income')} income / "
          f"{sum(1 for r in rows if r[4]=='expense')} expense)")
    print(f"  Date range : {START} -> {TODAY}")
    print(f"  Revenue    : ${income:,.2f}")
    print(f"  Expenses   : ${expense:,.2f}")
    print(f"  Net profit : ${income - expense:,.2f}")


if __name__ == "__main__":
    main()

