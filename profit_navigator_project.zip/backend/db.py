"""
Database connection pool for MySQL (Lumina) with automatic SQLite fallback.
Provides 100% zero-downtime database access regardless of local MySQL setup.
"""
import os
import sys
import sqlite3
import mysql.connector
from mysql.connector import pooling

DB_CONFIG = {
    "host": "localhost",
    "port": 3306,
    "user": "root",
    "password": "TVK@2026",
    "database": "Lumina",
    "charset": "utf8mb4",
    "collation": "utf8mb4_unicode_ci",
}

_pool = None
_use_sqlite = False
SQLITE_DB_PATH = os.path.join(os.path.dirname(__file__), "lumina_fallback.db")

def _init_sqlite_schema():
    """Create SQLite tables if falling back to SQLite."""
    conn = sqlite3.connect(SQLITE_DB_PATH)
    cursor = conn.cursor()
    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            phone TEXT UNIQUE NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            avatar_url TEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS login_otps (
            id TEXT PRIMARY KEY,
            identifier TEXT NOT NULL,
            user_id TEXT NULL,
            otp_hash TEXT NOT NULL,
            expires_at DATETIME NOT NULL,
            attempts INTEGER DEFAULT 0,
            used INTEGER DEFAULT 0,
            last_resend_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS revoked_tokens (
            token_hash TEXT PRIMARY KEY,
            revoked_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            amount REAL NOT NULL,
            type TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS products (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            price REAL NOT NULL,
            units_sold INTEGER DEFAULT 0,
            revenue REAL DEFAULT 0.00,
            trend TEXT DEFAULT 'stable',
            cluster TEXT DEFAULT 'question-mark',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS forecasts (
            id TEXT PRIMARY KEY,
            period TEXT NOT NULL,
            predicted_revenue REAL NOT NULL,
            predicted_expenses REAL NOT NULL,
            confidence REAL DEFAULT 0.0000,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS chat_messages (
            id TEXT PRIMARY KEY,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            session_id TEXT DEFAULT 'default',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS tutorials (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NULL,
            youtube_id TEXT NOT NULL,
            target_role TEXT DEFAULT 'both',
            video_ids TEXT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS page_visibility (
            page_url TEXT NOT NULL,
            role TEXT NOT NULL,
            visible INTEGER DEFAULT 1,
            PRIMARY KEY (page_url, role)
        );

        CREATE TABLE IF NOT EXISTS pricing_recommendations (
            id TEXT PRIMARY KEY,
            product_id TEXT NOT NULL,
            product_name TEXT NOT NULL,
            current_price REAL NOT NULL,
            suggested_price REAL NOT NULL,
            reason TEXT NULL,
            confidence INTEGER DEFAULT 0,
            expected_impact TEXT NULL,
            model_used TEXT DEFAULT 'rule_based',
            status TEXT DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            reviewed_at DATETIME NULL
        );
    """)
    try:
        cursor.execute("ALTER TABLE users ADD COLUMN phone TEXT UNIQUE NULL")
    except Exception:
        pass  # Column already exists
    conn.commit()
    conn.close()

# Try initializing MySQL pool, fall back to SQLite if MySQL unavailable
try:
    _pool = pooling.MySQLConnectionPool(
        pool_name="lumina_pool",
        pool_size=10,
        pool_reset_session=True,
        **DB_CONFIG,
    )
    # Test connection
    test_conn = _pool.get_connection()
    test_conn.close()
    print(">>> Database engine: Connected to MySQL (Lumina)")
except Exception as err:
    _use_sqlite = True
    print(f">>> Database engine: MySQL not available ({err}). Falling back to embedded SQLite ({SQLITE_DB_PATH})")
    _init_sqlite_schema()


def _convert_sql(sql: str) -> str:
    """Convert MySQL placeholders %s to SQLite placeholders ? if using SQLite."""
    if _use_sqlite:
        return sql.replace("%s", "?")
    return sql


def get_connection():
    """Get connection (MySQL or SQLite)."""
    if _use_sqlite:
        conn = sqlite3.connect(SQLITE_DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    return _pool.get_connection()


def query(sql, params=None, dictionary=True):
    """Execute a SELECT and return all rows as dicts."""
    sql = _convert_sql(sql)
    conn = get_connection()
    try:
        if _use_sqlite:
            cursor = conn.cursor()
            cursor.execute(sql, params or ())
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        else:
            cursor = conn.cursor(dictionary=dictionary)
            cursor.execute(sql, params or ())
            rows = cursor.fetchall()
            cursor.close()
            return rows
    finally:
        conn.close()


def execute(sql, params=None):
    """Execute an INSERT / UPDATE / DELETE and return lastrowid or rowcount."""
    sql = _convert_sql(sql)
    conn = get_connection()
    try:
        if _use_sqlite:
            cursor = conn.cursor()
            cursor.execute(sql, params or ())
            conn.commit()
            last_id = cursor.lastrowid
            return last_id
        else:
            cursor = conn.cursor()
            cursor.execute(sql, params or ())
            conn.commit()
            last_id = cursor.lastrowid
            cursor.close()
            return last_id
    finally:
        conn.close()


def execute_many(sql, data):
    """Execute a batch INSERT."""
    sql = _convert_sql(sql)
    conn = get_connection()
    try:
        if _use_sqlite:
            cursor = conn.cursor()
            cursor.executemany(sql, data)
            conn.commit()
        else:
            cursor = conn.cursor()
            cursor.executemany(sql, data)
            conn.commit()
            cursor.close()
    finally:
        conn.close()

