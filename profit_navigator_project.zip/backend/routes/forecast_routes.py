import uuid
import sys
import os
from flask import Blueprint, request, jsonify
from db import query, execute

# Add parent directory to sys.path if needed
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from python.forecast import run_forecast_model

forecast_bp = Blueprint("forecast", __name__)


@forecast_bp.route("/", methods=["POST"])
def run_forecast():
    """POST /api/forecast — build forecast from transactions, save to MySQL."""
    try:
        transactions = query(
            "SELECT id, date, description, category, amount, type "
            "FROM transactions ORDER BY date ASC"
        )

        if not transactions:
            return jsonify({
                "forecasts": [],
                "daily_forecast": [],
                "model_used": "none",
                "r2_score": 0.0,
                "historical": {"months": [], "revenues": [], "expenses": []}
            })

        # Group by month
        monthly = {}
        daily_income_map = {}
        for t in transactions:
            month = str(t["date"])[:7]  # YYYY-MM
            date_str = str(t["date"])
            if month not in monthly:
                monthly[month] = {"income": 0, "expense": 0}
            if t["type"] == "income":
                monthly[month]["income"] += float(t["amount"])
                daily_income_map[date_str] = daily_income_map.get(date_str, 0) + float(t["amount"])
            else:
                monthly[month]["expense"] += float(t["amount"])

        months = sorted(monthly.keys())
        revenues = [monthly[m]["income"] for m in months]
        expenses = [monthly[m]["expense"] for m in months]
        daily_sales = [daily_income_map[d] for d in sorted(daily_income_map.keys())]

        # Call Python ML model directly in-memory
        result = run_forecast_model({
            "months": months,
            "revenues": revenues,
            "expenses": expenses,
            "daily_sales": daily_sales,
            "future_count": 6
        })

        # Save forecasts to MySQL (clear old ones first)
        execute("DELETE FROM forecasts")
        forecasts = result.get("forecasts", [])
        for f in forecasts:
            fid = str(uuid.uuid4())
            execute(
                "INSERT INTO forecasts (id, period, predicted_revenue, predicted_expenses, confidence) "
                "VALUES (%s, %s, %s, %s, %s)",
                (fid, f["period"], f["predicted_revenue"], f["predicted_expenses"], f.get("confidence", 0)),
            )

        return jsonify({
            "forecasts": forecasts,
            "daily_forecast": result.get("daily_forecast", []),
            "model_used": result.get("model_used", "linear_regression"),
            "r2_score": result.get("r2_score", 0.0),
            "historical": {"months": months, "revenues": revenues, "expenses": expenses}
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500



@forecast_bp.route("/", methods=["GET"])
def get_forecasts():
    """GET /api/forecast — return saved forecasts from DB."""
    try:
        rows = query("SELECT * FROM forecasts ORDER BY period ASC")
        result = []
        for r in rows:
            result.append({
                "id": r["id"],
                "period": r["period"],
                "predicted_revenue": float(r["predicted_revenue"]),
                "predicted_expenses": float(r["predicted_expenses"]),
                "confidence": float(r["confidence"]),
                "created_at": str(r["created_at"]),
            })
        return jsonify({"forecasts": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
